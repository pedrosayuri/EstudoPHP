<?php

$idadeList = [21, 23, 54, 66];

for ($i = 0; $i < count($idadeList); $i++) {
    echo $idadeList[$i] . PHP_EOL;
}
#count('array') conta quantos elementos tem dentro do array.
#PHP_EOL Pula linha

